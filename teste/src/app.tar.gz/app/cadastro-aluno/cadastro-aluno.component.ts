import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cadastro-aluno',
  templateUrl: './cadastro-aluno.component.html',
  styleUrls: ['./cadastro-aluno.component.css']
})
export class CadastroAlunoComponent implements OnInit {
  cadastrados: string[];

  constructor() {
    this.cadastrados = [];
  }

  ngOnInit() {

  }

  existeAluno(): boolean {
    if (this.cadastrados.length > 0) {
      return true;
    }
    return false;
  }

  adicionar(a: string) {
    this.cadastrados.push(a);
  }

}
