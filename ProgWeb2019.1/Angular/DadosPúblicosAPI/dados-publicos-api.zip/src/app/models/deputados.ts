export class Deputados{
    id: number;
    nome: string;
    uf: string;
    partido: string;
}