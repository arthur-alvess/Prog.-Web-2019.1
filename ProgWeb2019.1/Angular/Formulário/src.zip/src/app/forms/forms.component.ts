import { Component, OnInit } from '@angular/core';
import { Usuario } from './usuario';

@Component({
  selector: 'app-forms',
  templateUrl: './forms.component.html',
  styleUrls: ['./forms.component.css']
})
export class FormsComponent implements OnInit {

  usuario:Usuario;
  //senha: string;

  constructor() { 
    this.usuario = new Usuario;
  }

  ngOnInit() {
  }

  consultar(){
    
    console.log(this.usuario)
  }

}
