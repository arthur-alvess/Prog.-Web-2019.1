export class Usuario{
    matricula: number;
    nome: string;
    email: string;
    senha: string;
    senha2: string;
}