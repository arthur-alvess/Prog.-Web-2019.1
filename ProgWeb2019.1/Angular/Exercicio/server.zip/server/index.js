const express = require('express');
const con = require ('./bd'); 
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({extended: true}));

app.listen(3000, () =>{
    con.connect((erro)=>{
        if(!erro){
            console.log('Servidor Okay');
        }else{
            console.log('Erro: ' + erro.sqlMessage)
        }
    })
});

app.get('/aluno', (req, res)=>{
    const sql = 'SELECT a.matricula, a.nome AS nomeAluno, a.periodo, c.nome as curso FROM aluno as a INNER JOIN curso as c ON a.curso = c.id ';
    con.query(sql, (erro, resultado) =>{
        if(!erro){
            res.send(resultado);
        }else{
            res.send(erro.sqlMessage);
        }
    })
})